package com.example.sweta.notificationsampleproj;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Arrays;
import java.util.List;

public class PinnedShortcutActivity extends AppCompatActivity {
    ShortcutManager mShortcutManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pinned_shortcut);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            mShortcutManager = getSystemService(ShortcutManager.class);
        }

        Button btnPinnedShortcut1 = (Button) findViewById(R.id.pinned_shortcut_btn_id1);

        btnPinnedShortcut1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestTestPinnedShortcut("shortcutId1");
            }
        });

        Button btnPinnedShortcut2 = (Button) findViewById(R.id.pinned_shortcut_btn_id2);

        btnPinnedShortcut2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestTestPinnedShortcut("dynamic_shortcut_id1");
            }
        });

        Button btnPinnedShortcut3 = (Button) findViewById(R.id.pinned_shortcut_btn_id3);

        btnPinnedShortcut3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestNewPinnedShortcut("pinned_shortcut_id1");
            }
        });

        Button btnPinnedShortcut4 = (Button) findViewById(R.id.pinned_shortcut_btn_id4);

        btnPinnedShortcut4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    mShortcutManager.disableShortcuts(Arrays.asList("pinned_shortcut_id1"));
                }
            }
        });

        Button btnPinnedShortcut5 = (Button) findViewById(R.id.pinned_shortcut_btn_id5);

        btnPinnedShortcut5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    mShortcutManager.enableShortcuts(Arrays.asList("pinned_shortcut_id1"));
                }
            }
        });

        Button btnPinnedShortcut6 = (Button) findViewById(R.id.pinned_shortcut_btn_id6);

        btnPinnedShortcut6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    ShortcutInfo shortcutInfo = new ShortcutInfo.Builder(getApplicationContext(), "pinned_shortcut_id1")
                            .setShortLabel("Amazon Prime")
                            .build();
                    mShortcutManager.updateShortcuts(Arrays.asList(shortcutInfo));
                }
            }
        });
    }

    private void requestNewPinnedShortcut(String shortcutId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mShortcutManager.isRequestPinShortcutSupported()) {
                ShortcutInfo pinShortcutInfo = new ShortcutInfo.Builder(this, shortcutId)
                        .setShortLabel("Amazon")
                        .setIcon(Icon.createWithResource(this.getApplicationContext(), R.drawable.test_shortcut_icon1))
                        .setIntent(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://www.amazon.in/")))
                        .build();

                if (!isShortcutAvailable(shortcutId)) {
                    Intent pinnedShortcutCallbackIntent =
                            mShortcutManager.createShortcutResultIntent(pinShortcutInfo);

                    PendingIntent successCallback = PendingIntent.getBroadcast(this.getApplicationContext(), 0,
                            pinnedShortcutCallbackIntent, 0);

                    mShortcutManager.requestPinShortcut(pinShortcutInfo,
                            successCallback.getIntentSender());
                }

            }
        }
    }

    private boolean isShortcutAvailable(String shortcutId) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N_MR1) {
            List<ShortcutInfo> shortcutInfoList = mShortcutManager.getPinnedShortcuts();
            for (ShortcutInfo shortcutInfo : shortcutInfoList) {
                String tempShortcutID = shortcutInfo.getId();
                if (tempShortcutID.equals(shortcutId)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void requestTestPinnedShortcut(String shortcutId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (mShortcutManager.isRequestPinShortcutSupported()) {
                ShortcutInfo pinShortcutInfo =
                        new ShortcutInfo.Builder(this.getApplicationContext(), shortcutId).build();

                // Create the PendingIntent object only if your app needs to be notified
                // that the user allowed the shortcut to be pinned. Note that, if the
                // pinning operation fails, your app isn't notified. We assume here that the
                // app has implemented a method called createShortcutResultIntent() that
                // returns a broadcast intent.
                Intent pinnedShortcutCallbackIntent =
                        mShortcutManager.createShortcutResultIntent(pinShortcutInfo);

                // Configure the intent so that your app's broadcast receiver gets
                // the callback successfully.
                PendingIntent successCallback = PendingIntent.getBroadcast(this.getApplicationContext(), 0,
                        pinnedShortcutCallbackIntent, 0);

                mShortcutManager.requestPinShortcut(pinShortcutInfo,
                        successCallback.getIntentSender());
            }
        }
    }
}

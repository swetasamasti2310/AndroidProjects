package com.example.sweta.notificationsampleproj;

import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;

import java.util.Arrays;

public class DynamicShortcut1Activity extends AppCompatActivity {
    ShortcutManager shortcutManager;
    private NotificationUtils mNotificationUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dynamic_shortcut1);
        mNotificationUtils = new NotificationUtils(this);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            shortcutManager = getSystemService(ShortcutManager.class);
        }

        Button btnDynamicShortcut1 = (Button) findViewById(R.id.dynamic_shortcut_btn_id1);
        Button btnDynamicShortcut2 = (Button) findViewById(R.id.dynamic_shortcut_btn_id2);
        Button btnDynamicShortcut3 = (Button) findViewById(R.id.dynamic_shortcut_btn_id3);
        Button btnDynamicShortcut4 = (Button) findViewById(R.id.dynamic_shortcut_btn_id4);
        Button btnDynamicShortcut5 = (Button) findViewById(R.id.dynamic_shortcut_btn_id5);
        Button btnDynamicShortcut6 = (Button) findViewById(R.id.dynamic_shortcut_btn_id6);
        Button btnDynamicShortcut7 = (Button) findViewById(R.id.dynamic_shortcut_btn_id7);

        btnDynamicShortcut1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                createTestDynamicShortcut1("dynamic_shortcut_id1");
            }
        });

        btnDynamicShortcut2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addTestDynamicShortcut2("dynamic_shortcut_id2");
            }
        });

        btnDynamicShortcut3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateTestDynamicShortcut("dynamic_shortcut_id2");
            }
        });

        btnDynamicShortcut4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    shortcutManager.removeDynamicShortcuts(Arrays.asList("dynamic_shortcut_id1"));
                }
            }
        });

        btnDynamicShortcut5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
                    shortcutManager.removeAllDynamicShortcuts();
                }
            }
        });

        btnDynamicShortcut6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification("Dynamic", "Channel 33 msg " + "author", NotificationUtils.ANDROID_CHANNEL_ID3);
                mNotificationUtils.getManager().notify(6, nb.build());
            }
        });

        btnDynamicShortcut7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification("Dynamic", "Channel 34 msg " + "author", NotificationUtils.ANDROID_CHANNEL_ID4);
                mNotificationUtils.getManager().notify(7, nb.build());
            }
        });
    }

    private void updateTestDynamicShortcut(String shortcutId) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            ShortcutInfo shortcut = new ShortcutInfo.Builder(this, shortcutId)
                    .setShortLabel("Web site")
                    .setLongLabel("Open the web site")
                    .setIcon(Icon.createWithResource(this.getApplicationContext(), R.drawable.test_shortcut_icon1))
                    .setIntent(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.google.com/")))
                    .build();

            shortcutManager.updateShortcuts(Arrays.asList(shortcut));
        }
    }

    private void createTestDynamicShortcut1(String shortcutId) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            ShortcutInfo shortcut = new ShortcutInfo.Builder(this, shortcutId)
                    .setShortLabel("Web site")
                    .setLongLabel("Open the web site")
                    .setIcon(Icon.createWithResource(this.getApplicationContext(), R.drawable.test_shortcut_icon1))
                    .setIntent(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.google.com/")))
                    .build();

            shortcutManager.setDynamicShortcuts(Arrays.asList(shortcut));
        }
    }

    private void addTestDynamicShortcut2(String shortcutId) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.N_MR1) {
            ShortcutManager shortcutManager = getSystemService(ShortcutManager.class);

            ShortcutInfo shortcut = new ShortcutInfo.Builder(this, shortcutId)
                    .setShortLabel("Social Site")
                    .setLongLabel("Open facebook")
                    .setIcon(Icon.createWithResource(this.getApplicationContext(), R.drawable.test_shortcut_icon1))
                    .setIntent(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://www.facebook.com/")))
                    .build();

            shortcutManager.addDynamicShortcuts(Arrays.asList(shortcut));
        }
    }
}


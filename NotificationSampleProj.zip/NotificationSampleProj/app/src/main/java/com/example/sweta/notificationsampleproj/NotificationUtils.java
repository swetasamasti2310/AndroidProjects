package com.example.sweta.notificationsampleproj;

import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.support.v4.app.NotificationCompat;

/**
 * Created by sweta on 9/9/2017.
 */

public class NotificationUtils extends ContextWrapper {
    private NotificationManager mManager;
    public static final String ANDROID_CHANNEL_ID1 = "sampleAlertTest1";
    public static final String ANDROID_CHANNEL_ID2 = "sampleAlertTest2";
    public static final String ANDROID_CHANNEL_ID3 = "sampleAlertTest3";
    public static final String ANDROID_CHANNEL_ID4 = "sampleAlertTest4";

    public static final String ANDROID_CHANNEL_NAME1 = "Test1_CHANNEL";
    public static final String ANDROID_CHANNEL_NAME2 = "Test2_CHANNEL";
    public static final String ANDROID_CHANNEL_NAME3 = "Test3_CHANNEL";
    public static final String ANDROID_CHANNEL_NAME4 = "Test4_CHANNEL";

    public NotificationUtils(Context base) {
        super(base);
    }

    public void createChannels() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {

            NotificationChannel androidChannel1 = new NotificationChannel(ANDROID_CHANNEL_ID1, ANDROID_CHANNEL_NAME1, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationChannel androidChannel2 = new NotificationChannel(ANDROID_CHANNEL_ID2, ANDROID_CHANNEL_NAME2, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationChannel androidChannel3 = new NotificationChannel(ANDROID_CHANNEL_ID3, ANDROID_CHANNEL_NAME1, NotificationManager.IMPORTANCE_DEFAULT);
            NotificationChannel androidChannel4 = new NotificationChannel(ANDROID_CHANNEL_ID4, ANDROID_CHANNEL_NAME4, NotificationManager.IMPORTANCE_DEFAULT);

            createSampleNotificationChannelGroup("group_id_01", "group_name_01");
            createSampleNotificationChannelGroup("group_id_02", "group_name_02");

            androidChannel1.setGroup("group_id_01");
            androidChannel2.setGroup("group_id_01");
            androidChannel3.setGroup("group_id_02");
            androidChannel4.setGroup("group_id_02");

            getManager().createNotificationChannel(androidChannel1);
            getManager().createNotificationChannel(androidChannel2);
            getManager().createNotificationChannel(androidChannel3);
            getManager().createNotificationChannel(androidChannel4);

        }
    }

    public NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }

    public NotificationCompat.Builder getAndroidChannelNotification(String title, String body, String channelId) {
        NotificationCompat.Builder nb;
        nb = new NotificationCompat.Builder(getApplicationContext(), channelId);
        nb.setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setAutoCancel(true);
        return nb;
    }

    public void createSampleNotificationChannelGroup(String groupId, String groupName) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannelGroup notificationChannelGroup = new NotificationChannelGroup(groupId, groupName);
            getManager().createNotificationChannelGroup(notificationChannelGroup);
        }
    }

    public void setChannelToGroup(NotificationChannel channel, String groupId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            channel.setGroup(groupId);
        }
    }
}

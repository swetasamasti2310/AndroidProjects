package com.example.sweta.notificationsampleproj;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private NotificationUtils mNotificationUtils;
    private WidgetUtils mWidgetUtils;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNotificationUtils = new NotificationUtils(this);
        mNotificationUtils.createChannels();

        final EditText editTextTitleAndroid = (EditText) findViewById(R.id.android_title_id);
        final EditText editTextAuthorAndroid = (EditText) findViewById(R.id.android_author_id);
        final EditText editTextTitleIos = (EditText) findViewById(R.id.ios_title_id);
        final EditText editTextAuthorIos = (EditText) findViewById(R.id.ios_author_id);

        Button btnChannel11 = (Button) findViewById(R.id.channel_button_id11);
        Button btnChannel12 = (Button) findViewById(R.id.channel_button_id12);
        Button btnChannel22 = (Button) findViewById(R.id.channel_button_id22);
        Button btnChannel23 = (Button) findViewById(R.id.channel_button_id23);
        Button btnChannel24 = (Button) findViewById(R.id.channel_button_id24);

        Button btnWidget1 = (Button) findViewById(R.id.widget_button_id1);

        btnWidget1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    AppWidgetManager mAppWidgetManager =
                            getApplicationContext().getSystemService(AppWidgetManager.class);
                    ComponentName myProvider =
                            new ComponentName(getApplicationContext(), SampleAppWidgetProvider.class);

                    if (mAppWidgetManager != null && mAppWidgetManager.isRequestPinAppWidgetSupported()) {
                        Intent pinnedWidgetCallbackIntent = new Intent(getApplication(), PinnedShortcutActivity.class);

                        PendingIntent successCallback = PendingIntent.getBroadcast(getApplicationContext(), 0,
                                pinnedWidgetCallbackIntent, 0);

                        mAppWidgetManager.requestPinAppWidget(myProvider, null, successCallback);
                    }
                }
            }
        });

        btnChannel11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editTextTitleAndroid.getText().toString();
                String author = editTextAuthorAndroid.getText().toString();

                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(author)) {
                    NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification(title, "channel11 msg " + author, NotificationUtils.ANDROID_CHANNEL_ID1);
                    mNotificationUtils.getManager().notify(1, nb.build());
                }
            }
        });

        btnChannel12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editTextTitleIos.getText().toString();
                String author = editTextAuthorIos.getText().toString();

                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(author)) {
                    NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification(title, "channel12 msg " + author, NotificationUtils.ANDROID_CHANNEL_ID2);
                    mNotificationUtils.getManager().notify(2, nb.build());
                }
            }
        });

        btnChannel22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editTextTitleAndroid.getText().toString();
                String author = editTextAuthorAndroid.getText().toString();

                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(author)) {
                    NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification(title, "channel 22 msg " + author, NotificationUtils.ANDROID_CHANNEL_ID2);
                    mNotificationUtils.getManager().notify(3, nb.build());
                }
            }
        });

        btnChannel23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editTextTitleAndroid.getText().toString();
                String author = editTextAuthorAndroid.getText().toString();

                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(author)) {
                    NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification(title, "Channel 23 msg " + author, NotificationUtils.ANDROID_CHANNEL_ID3);
                    mNotificationUtils.getManager().notify(4, nb.build());
                }
            }
        });

        btnChannel24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editTextTitleAndroid.getText().toString();
                String author = editTextAuthorAndroid.getText().toString();

                if (!TextUtils.isEmpty(title) && !TextUtils.isEmpty(author)) {
                    NotificationCompat.Builder nb = mNotificationUtils.getAndroidChannelNotification(title, "Channel 24 msg " + author, NotificationUtils.ANDROID_CHANNEL_ID4);
                    mNotificationUtils.getManager().notify(5, nb.build());
                }
            }
        });

    }
}

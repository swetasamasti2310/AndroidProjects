package com.example.sweta.notificationsampleproj;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;

/**
 * Created by sweta on 9/28/2017.
 */

public class WidgetUtils extends ContextWrapper {
    public WidgetUtils(Context base) {
        super(base);
    }

    public void createWidget() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            AppWidgetManager mAppWidgetManager =
                    getApplicationContext().getSystemService(AppWidgetManager.class);
            ComponentName myProvider =
                    new ComponentName(getApplicationContext(), SampleAppWidgetProvider.class);

            if (mAppWidgetManager != null && mAppWidgetManager.isRequestPinAppWidgetSupported()) {
                // Create the PendingIntent object only if your app needs to be notified
                // that the user allowed the widget to be pinned. Note that, if the pinning
                // operation fails, your app isn't notified.
                //Intent pinnedWidgetCallbackIntent = null;

                // Configure the intent so that your app's broadcast receiver gets
                // the callback successfully. This callback receives the ID of the
                // newly-pinned widget (EXTRA_APPWIDGET_ID).
                /*PendingIntent successCallback = PendingIntent.createBroadcast(getApplicationContext(), 0,
                        pinnedWidgetCallbackIntent);*/

                mAppWidgetManager.requestPinAppWidget(myProvider, null, null);
            }
        }
    }
}
